import javax.swing.JFrame;

public class GameFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	static JFrame jogo = new JFrame();
	GameFrame(){
	
		jogo.add(new GamePanel());
		jogo.setTitle("Corrida Maluca - A2 - Sistemas Distribuidos - 2021");
		jogo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jogo.setResizable(false);
		jogo.pack();
		jogo.setVisible(true);
		jogo.setLocationRelativeTo(null);
	}
	
	public static void gjoo() {
		jogo.dispose();
	}
}
