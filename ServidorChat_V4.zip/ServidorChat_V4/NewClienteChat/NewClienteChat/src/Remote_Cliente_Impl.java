
import java.rmi.*;
import java.rmi.server.*;
public class Remote_Cliente_Impl extends UnicastRemoteObject implements Chat_Cliente_Interface {


	private static final long serialVersionUID = 1L;
	private javax.swing.JTextArea textArea;
	private String name;
	private int id;
	
    public Remote_Cliente_Impl(javax.swing.JTextArea ta) throws RemoteException {	
    	textArea = ta;
    }
    
    public void JuntarMensagem(String name, int I) throws RemoteException
    {
    	setName(name);
	    setId(I);
    }
    
    public void enviarGanhador(String msg) throws RemoteException {
        try {
    	    GamePanel.chamarGameOver(msg);
	    }
        catch(Exception e){
            System.out.println("DisplayMessage -> Falha no envio da Mesagem");
            e.printStackTrace();
        };
    }
    
    public void AtualizarChat(String msg) throws RemoteException {
    	textArea.setText(msg);
    }
 
    public void fazerInicioDoJogo() throws RemoteException{
        NewClienteChat.iniciarOJogo();
    }
    
    public void setName(String name) {
    	this.name = name;
    }
    
    public String getName() {
    	return name;
    }
    
    public void setId(int id) {
    	this.id = id;
    }
    
    public int getId() {
    	return id;
    }
}
