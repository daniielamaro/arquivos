
import java.rmi.*;

public interface Chat_Servidor_Interface extends Remote {
	
	public void juntar(Chat_Cliente_Interface n, String name) throws RemoteException;
    public void conversar(String name, String s) throws RemoteException;
    public void deixar(Chat_Cliente_Interface n, String name) throws RemoteException;
    public void jogadorPronto(String name) throws RemoteException;
	public void ganhador(String name) throws RemoteException;
	
}
