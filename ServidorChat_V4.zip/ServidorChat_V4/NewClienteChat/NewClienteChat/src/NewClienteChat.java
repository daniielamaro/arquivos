import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JPanel;
import javax.swing.JLabel;

import javax.swing.JOptionPane;
// Importando classes RMI
import java.rmi.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewClienteChat {
// ****************************************************************************************	
//                Descricao resumida das FASES da aplicacao NewClienteChat
//
// Primeira fase - dentro do metodo main()       -> Criar thread para executar a aplicacao
// Segunda  fase - dentro do metodo main()       -> Instanciar e criar a janela da aplicacao
// Terceira fase - dentro do metodo initialize() -> Obter um socket Cliente RMI -> invocacando  
//                                                  o metodo lookup("rmichat") da classe Naming RMI
// Quarta   fase - dentro do metodo initialize() -> Incluir os m�todos OUVINTE para a janela ou  
//													componentes especificos (botao, mouse teclado)
//													Teremos v�rios ouvintes, um para cada evento que 
// 													sera incluido proximo ao componente
// Quinta   fase - iniciar a classe da sua aplicacao
// **************************************************************************************** 

	// DECLARACAO DOS CAMPOS DA CLASSE NewClienteChat
	//
	//       Campos usados para criar a JANELA da aplicacao
	//
	private JFrame frmNewClienteChat;
	private static JTextArea otherText; //= new JTextArea();
	private JLabel lblTransmitir_1;
	private JLabel lblReceber_1;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	private JTextArea myText ;
	private JButton btnLogin;
	private static JButton btnMeuBotao_1; 
	private static JButton btnMeuBotao_2; 
	
	//       Campos usados para a aplicacao funcionar
	//
    private String textString = "";
    private boolean primeiraMensagem = true;  // Usada para processar a PRIMEIRA MENSAGEM com o servidor
    private static String name = null;    // se name = null o cliente n�o est� associado
    static Chat_Cliente_Interface displayChat;		    // Instancia da interface Cliente  - servidor  (invoca metodos no) -> cliente 
    static Chat_Servidor_Interface chatServer;         // Instancia da interface Servidor - cliente   (invoca metodos no) -> servidor     


    // *************************************************************************
    // Metodo Construtor da classe NewClienteChat()
    // *************************************************************************
	public NewClienteChat() {
		// Invoca o m�todo initialize() para iniciar os componentes da classe NewClienteChat
		initialize();
	 

	} // Fim do metodo construtor  da classe NewClienteChat()

	// ************************************************************************
	// Metodo para iniciar os componentes da classe (aplicacao NewClienteChat)
	// isto e' criar a janela, caixa de texto, botao ...
    // *************************************************************************	
	private void initialize() {
		frmNewClienteChat = new JFrame();
        // ****************************************************************************************
    	// Quarta fase: Invoca METODO OUVINTE de evento   OBS.: Teremos VARIOS OUVINTES um p cada evevto
		// 4� - A
		// Evento de FECHAR a aplicacao -> windowClosing(WindowEvent arg0) 
		//
    	// Metodo para adiciona um OUVINTE para a janela ou componente especifico da aplicacao.
        // O ouvinte receber os eventos a partir desta janela. Se for nulo, nenhuma exce��o � lan�ada  
        // e nenhuma a��o � executada.
		//
        // WindowAdapter() -> Classe abstrada do adaptador para receber os eventos da janela
        // windowClosing(WindowEvent e) -> M�todo invocado quando a janela est� no processo de fechar 
        // ****************************************************************************************           	   			
		frmNewClienteChat.addWindowListener(new WindowAdapter() {
						
			@Override
			public void windowClosing(WindowEvent arg0) {
				try {
					if (name != null) {
					    chatServer.deixar(displayChat, name);
					}
			}
			catch (Exception ex) {
				 otherText.append("Sair falhou.");
			}
			System.exit(0);
				
				
			}
		});		
		
		frmNewClienteChat.setTitle("New Cliente Chat");
		frmNewClienteChat.setBounds(100, 100, 463, 347);
		frmNewClienteChat.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // ****************************************************************************************		
		// Trata os eventos do botao Login
		//
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (primeiraMensagem) { 
				
	        	   try {
        		       name = JOptionPane.showInputDialog("Digite seu nome: ");
        		       
        		       if(name != null && !name.equals("")) {
        		    	   chatServer.juntar(displayChat,name);
            			   primeiraMensagem = false;
            			   btnMeuBotao_2.setVisible(true);
    					   btnLogin.setVisible(false);
    					   scrollPane.setVisible(true);
    					   scrollPane_1.setVisible(true);
    		        	   myText.append("Digite sua mesagem.\n");
        		       }       
	        	   }
	        	   catch (Exception ie) {
	        		   otherText.append("Falha no envio de mesagem.");
	        	   }  
				}
			}
		});
        // ****************************************************************************************		
		// Trata os eventos do botao MeuBotao_1
		//
		btnMeuBotao_1 = new JButton("Iniciar Jogo");
		btnMeuBotao_1.setVisible(false);
		btnMeuBotao_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btnMeuBotao_1.setVisible(false);
				new GameFrame();
			}
		});
		
		btnMeuBotao_2 = new JButton("Pronto");
		btnMeuBotao_2.setVisible(false);
		btnMeuBotao_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					btnMeuBotao_2.setVisible(false);
					chatServer.jogadorPronto(name);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		});
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		JPanel panel = new JPanel();
		
		GroupLayout groupLayout = new GroupLayout(frmNewClienteChat.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.UNRELATED))
						.addComponent(btnLogin))
					.addComponent(btnMeuBotao_2)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(btnMeuBotao_1)
						
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)))
					.addContainerGap())
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 447, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 85, GroupLayout.PREFERRED_SIZE)
						.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 84, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(btnLogin)
						.addComponent(btnMeuBotao_1)
						.addComponent(btnMeuBotao_2))
					
					.addContainerGap())
		);
		
		JLabel lblIncluaSuaAplicao = new JLabel("Jogo Corrida Maluca!");
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addGap(170)
					.addComponent(lblIncluaSuaAplicao, GroupLayout.PREFERRED_SIZE, 178, Short.MAX_VALUE)
					.addGap(116))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addGap(85)
					.addComponent(lblIncluaSuaAplicao, GroupLayout.PREFERRED_SIZE, 9, Short.MAX_VALUE)
					.addGap(79))
		);
		panel.setLayout(gl_panel);
		
		// Alterar o local da declara��o original do windowBuilder para que o escopo do objeto otherText
		// seja visivel em toda classe NewClienteChat
		//final JTextArea otherText = new JTextArea(); 
		
		otherText = new JTextArea();
		scrollPane_1.setViewportView(otherText);
		
		lblReceber_1 = new JLabel("Receber");
		scrollPane_1.setColumnHeaderView(lblReceber_1);
		
		// Alterar o local da declara��o original do windowBuilder para que o escopo do objeto otherText
		// seja visivel em toda classe NewClienteChat 
		// JTextArea myText = new JTextArea();
		myText = new JTextArea();
		//myText.setFocusCycleRoot(true);
   	    // *********************************************************************************
   	   	// M�todo de myText.addKeyListener() 
   	    //      Adiciona um OUVINTE para a janela especificada, para receber os eventos a partir
        //  desta janela. 
   	    //  Usa o m�todo    textTyped(evt) -> para processar os caracteresdigitados 
   	    //
  	    // *********************************************************************************
		myText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent arg0) {
				
				textTyped(arg0);
			}
		});
		scrollPane.setViewportView(myText);
		//myText.append("Digite seu nome:\n");
		
		lblTransmitir_1 = new JLabel("Transmitir");
		scrollPane.setColumnHeaderView(lblTransmitir_1);
		scrollPane.setVisible(false);
		scrollPane_1.setVisible(false);
		frmNewClienteChat.getContentPane().setLayout(groupLayout);
		
		    		
        try {
            Remote remoteObject = Naming.lookup("rmichat");
            
            // Se interface esta OK
			if (remoteObject instanceof Chat_Servidor_Interface) {
				// Obtem interface remota
				chatServer = (Chat_Servidor_Interface)remoteObject ;
				
				// Inst�nciando a classe DisplayMessage() p/ q o ClienteCht possa usar 
				displayChat = new Remote_Cliente_Impl(otherText);
			} else {
				System.out.println("O Servidor nao e� um Servidor de Chat");
				System.exit(0);
			}
        }
        catch(Exception e){
            System.out.println("Pesquisando exce��o de RMI - Lookup Exception");
            System.exit(0);
        };// Fim do try Remote remoteObject
			

        
        
	}// Fim do M�todo initialize()
	
	public static void iniciarOJogo() {
        btnMeuBotao_2.setVisible(false);
        btnMeuBotao_2.setEnabled(false);
        btnMeuBotao_1.setVisible(true);
        btnMeuBotao_1.setEnabled(true);
    }
	
	public static void ganhador() {
		  try {
   		   // Se for a PRIMEIRA MENSAGEM enviada do cliente para o servidor
   		   // ser� armazenado este texto em nome do cliente e o cliente ser� 
   		   // associado ao chat. e a v�riavel firstMessage � colocada com falso  
   		       chatServer.ganhador(name);
   			   
   	   }
   	   catch (Exception ie) {
   		   otherText.append("Falha no envio de mesagem.");
   	   }

	}
	
    // *************************************************************************
    // M�todo para processar os textos digitados pelo cliente 
    // *************************************************************************    
    private void textTyped(java.awt.event.KeyEvent evt) {
        char c = evt.getKeyChar();
        if (c == '\n'){
        	   try {
        		   // Se for a PRIMEIRA MENSAGEM enviada do cliente para o servidor
        		   // ser� armazenado este texto em nome do cliente e o cliente ser� 
        		   // associado ao chat. e a v�riavel firstMessage � colocada com falso  
        		   if (primeiraMensagem) { 
        		   	   name = textString;
        		       chatServer.juntar(displayChat,name);
        			   primeiraMensagem = false;
        		   } else {
        			   // *******************************************************************
        			   // Obs:  1
        			   // Todas as OUTRAS mensagens são enviadas para o servidor por este 
        			   // método e CERTAS AÇÕES podem ser tratadas aqui ou no método conversar().
        			   //        		       												
        			   //
        			   // *******************************************************************
        			   
        			   chatServer.conversar(name, textString);
        		   }
        	   }
        	   catch (Exception ie) {
        		   otherText.append("Falha no envio de mesagem.");
        	   }
            textString = "";
        } else {
            textString = textString + c;
        }
    }// Fim do m�todo textTyped	
	
// *************************************************************************   
// Metodo main() - Metodo  que executa a classe  NewClienteChat()
// *************************************************************************
	public static void main(String[] args) {

        // ****************************************************************************************
    	// Primeira fase: 
    	// Invoca o METODO invokeLater da classe Thread para obter uma thread para executar
    	// a classe NewClienteChat (a aplicacao -> criar a janela, caixa de texto, botao ...) como 
        // ****************************************************************************************		
		//
		// 1� A - Cria uma thread para controlar a execucao da aplicacao
		
		EventQueue.invokeLater(new Runnable() {
			
		// 1� B - Faz a thread executar ( metodo-> public void run() ) e ...
		// *****************************************************************************
			public void run() {
				try {
					// *****************************************************************************
			    	// Segunda fase: Descricao do comando-> NewClienteChat window = new NewClienteChat();
					//
					// 2� A - Cria uma instancia da classe NewClienteChat (comando-> NewClienteChat window)
					// 
					// 2� B - INVOCA o metodo construtor da classe NewClienteChat() usando o 
					//  operador "new" ( comando ->   new NewClienteChat();)
					//
					// 2� C - O metodo construtor invoca o metodo initialize() para INICIAR os 
					// componentes da aplicacao isto e', criar a janela com seus componentes 
					// tais como: caixa de textos, botao, menu, barras etc....
					// *****************************************************************************
					NewClienteChat window = new NewClienteChat();
					window.frmNewClienteChat.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});// fim do metodo invokeLater()
	}// Fim do main()
} // Fim da classe NewClienteChat
