
import java.rmi.*;

public interface Chat_Cliente_Interface extends Remote {
	
	public void enviarGanhador(String msg) throws RemoteException;
	public void fazerInicioDoJogo() throws RemoteException;
	public void JuntarMensagem(String name,  int I) throws RemoteException;
	public void AtualizarChat(String message) throws RemoteException;
       
}
