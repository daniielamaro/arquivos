
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.*;
import java.util.*;

public class Servidor extends UnicastRemoteObject implements Chat_Servidor_Interface {
    
	private static final long serialVersionUID = 1L;

	protected Servidor() throws RemoteException {
		super();
	}

	public int NumJogadorCont = 0;
	public int NumJogadorProntCont = 0;
    private Servidor_Thread serverList = new Servidor_Thread();
    private static String textChat = ""; 
   
	public void juntar(Chat_Cliente_Interface n, String name) throws RemoteException {
		serverList.add(n);
		textChat += name + " juntou-se na posicao I = " + NumJogadorCont + " \n";
		serverList.incCounter();
		for (Iterator i = serverList.getCollection().iterator(); i.hasNext();) {
			Chat_Cliente_Interface client = (Chat_Cliente_Interface)i.next();
			client.AtualizarChat(textChat);
			client.JuntarMensagem(name, NumJogadorCont);
		}
		
		serverList.decCounter();
		
		NumJogadorCont++;
    }
	
	public void conversar(String name, String s) throws RemoteException {
		serverList.incCounter();
		textChat += name + " diz : " + s + "\n";
		for (Iterator i = serverList.getCollection().iterator(); i.hasNext();) {
			Chat_Cliente_Interface client = (Chat_Cliente_Interface)i.next();
			client.AtualizarChat(textChat);
		}
		serverList.decCounter();
    }
	
	public synchronized void deixar(Chat_Cliente_Interface n, String name) throws RemoteException {
    	serverList.remove(n);
    	textChat += name + " deixou o chat.\n";
    	serverList.incCounter();
    	for (Iterator i = serverList.getCollection().iterator(); i.hasNext();) {
			Chat_Cliente_Interface client = (Chat_Cliente_Interface)i.next();
			client.AtualizarChat(textChat);
		}
		serverList.decCounter();
    }
	
	public void jogadorPronto(String name) throws RemoteException {
        serverList.incCounter();
        textChat += "O jogador " + name + " est� pronto para jogar \n";
        for (Iterator i = serverList.getCollection().iterator(); i.hasNext();) {
            Chat_Cliente_Interface client = (Chat_Cliente_Interface)i.next();
            client.AtualizarChat(textChat);
        }

        serverList.decCounter();
        NumJogadorProntCont++; 
        verificarJogadoresProntos();  
    }
	
	public synchronized void verificarJogadoresProntos() throws RemoteException {
        if(NumJogadorProntCont >= 3) {
        	serverList.incCounter();
            
            for (Iterator i = serverList.getCollection().iterator(); i.hasNext();) {
                Chat_Cliente_Interface client = (Chat_Cliente_Interface)i.next();
                client.fazerInicioDoJogo();
            }

            serverList.decCounter();
        }

    }
	
	public void ganhador(String name) throws RemoteException {
		serverList.incCounter();
		
		textChat += "O jogador " + name + " ganhou! \n";
		for (Iterator i = serverList.getCollection().iterator(); i.hasNext();) {
			Chat_Cliente_Interface client = (Chat_Cliente_Interface)i.next();
			client.enviarGanhador("O jogador " + name + " ganhou!");
		}
		
		serverList.decCounter();
    }
	
	public static void main(String[] args) {
     	try { 
            LocateRegistry.createRegistry(1099);
			Servidor server = new Servidor();
			Naming.rebind("rmichat", server);
			System.out.println ("Servidor Pronto!");
		}
		catch (java.net.MalformedURLException e) {
			System.out.println("Nome da URL mal formado para Servidor de Mesagem. Erro: " + e.toString());
		}
		catch (RemoteException e) {
			System.out.println("Erro de comunica��o. Erro: " + e.toString());
		}
    }
    
}
